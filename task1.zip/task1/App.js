import React from "react";
import Sidebar from "./components/Sidebar";
import Board from "./components/Board";

export default function App() {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <Board />
    </div>
  );
}